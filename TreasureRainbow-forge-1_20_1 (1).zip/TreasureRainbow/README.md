# Arcoíris del Tesoro (mod para Minecraft Forge 1.20.1)

Durante el día aparecen arcoíris por el mapa. Donde termina cada uno hay un **cofre del tesoro** con recompensas muy especiales.

## Cómo conseguir el .jar con GitHub
1. Crea un repositorio nuevo en GitHub.
2. Sube **todo el contenido** de esta carpeta (incluida la carpeta oculta `.github`).
   Si la subida web no incluye `.github`, crea el archivo a mano con
   *Add file > Create new file* y el nombre `.github/workflows/build.yml`.
3. En la pestaña **Actions** se ejecuta solo "Compilar mod (.jar)" (unos minutos).
4. Al terminar en verde, descarga el artefacto **TreasureRainbow-jar**: dentro está `treasure_rainbow-1.0.0.jar`.
   Cópialo a la carpeta `mods` de Forge 1.20.1 (47.3.0 o superior). Ese mismo .jar se sube a CurseForge.

## Cómo funciona
- **Cuándo**: solo en el Overworld, de día y sin tormenta. Cada 20 segundos hay una pequeña probabilidad
  por jugador (6 %). **Justo después de que pare de llover sube al 40 %** durante unos 5 minutos.
- **Dónde**: en campo abierto, a 50-90 bloques del jugador, sobre suelo sólido y con cielo despejado.
  Nunca hay dos arcoíris a menos de 110 bloques.
- **El arcoíris**: un arco de 7 colores (rojo fuera, violeta dentro) de tamaño variable que aparece poco a poco.
  Se ve desde lejos. Un extremo acaba en el cofre.
- **Cuánto dura**: unos 12 minutos, hasta que anochezca o haya tormenta, o hasta unos 5 segundos después de que
  alguien abra el cofre. Si nadie lo abre, el cofre se esfuma con el arcoíris.
- **El cofre** brilla y suelta destellos de colores. Al abrirlo por primera vez estalla una celebración.
  Después se queda como un cofre normal que puedes romper y llevarte (se puede colocar como decoración).

## El tesoro
- **Siempre**: 1 Gema arcoíris (30 % de una segunda) y 3-8 Polvo de arcoíris.
- **Riquezas** (4-6 tiradas): diamantes, esmeraldas, oro, botellas de experiencia, manzanas doradas, perlas de ender,
  chatarra de netherita, lapislázuli, amatista, etiquetas, sillas...
- **Especiales** (1-2 tiradas): manzana dorada encantada, tótem de la inmortalidad, libro encantado de nivel alto
  (con encantamientos de tesoro como Reparación), lingotes de netherita, corazón del mar, pico y espada de diamante
  encantados, tridente encantado, elytras, estrella del Nether, discos Pigstep y Otherside.

## Objetos
- **Gema arcoíris**: clic derecho para consumirla. Da 7 efectos durante 3 minutos, uno por color:
  Fuerza (rojo), Resistencia al fuego (naranja), Suerte (amarillo), Regeneración (verde),
  Gracia del delfín (azul), Visión nocturna (añil) y Resistencia (violeta).
- **Polvo de arcoíris**: 1 lana blanca + 2 polvos = **Lana arcoíris** (bloque animado que cambia de color).
- **Cofre del arcoíris**: solo en creativo o recogiéndolo tras abrirlo.

## Probarlo sin esperar
Como operador, escribe `/rainbow`: crea un arcoíris con su cofre a unos 24-38 bloques de ti.
Ese arcoíris no desaparece al anochecer (solo por el tiempo, por la tormenta no, o al abrir el cofre).

## Ajustes rápidos
- `RainbowEvents.java`: `BASE_CHANCE`, `AFTER_RAIN_CHANCE`, `CHECK_INTERVAL`.
- `RainbowSpawner.java`: distancia de aparición y `MIN_SPACING`.
- `RainbowEntity.java`: `DEFAULT_LIFE` (duración).
- `data/treasure_rainbow/loot_tables/chests/rainbow_treasure.json`: el botín (pesos y cantidades).
- `RainbowRenderer.java`: colores, grosor y transparencia del arco.
