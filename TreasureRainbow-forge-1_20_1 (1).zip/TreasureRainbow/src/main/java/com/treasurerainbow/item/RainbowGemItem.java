package com.treasurerainbow.item;

import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/** Gema arcoíris: un efecto por cada color del arcoíris durante 3 minutos. */
public class RainbowGemItem extends Item {
    private static final int DURATION = 3600;

    public RainbowGemItem(Properties properties) {
        super(properties);
    }

    private static MobEffect[] effects() {
        return new MobEffect[]{
                MobEffects.DAMAGE_BOOST,       // rojo: fuerza
                MobEffects.FIRE_RESISTANCE,    // naranja: resistencia al fuego
                MobEffects.LUCK,               // amarillo: suerte
                MobEffects.REGENERATION,       // verde: regeneración
                MobEffects.DOLPHINS_GRACE,     // azul: gracia del delfín
                MobEffects.NIGHT_VISION,       // añil: visión nocturna
                MobEffects.DAMAGE_RESISTANCE   // violeta: resistencia
        };
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!level.isClientSide) {
            for (MobEffect effect : effects()) {
                player.addEffect(new MobEffectInstance(effect, DURATION, 0));
            }
            level.playSound(null, player.blockPosition(), SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.PLAYERS, 1.0F, 1.0F);
            level.playSound(null, player.blockPosition(), SoundEvents.PLAYER_LEVELUP, SoundSource.PLAYERS, 0.6F, 1.4F);
            if (level instanceof ServerLevel serverLevel) {
                serverLevel.sendParticles(ParticleTypes.TOTEM_OF_UNDYING, player.getX(), player.getY() + 1.0D, player.getZ(),
                        40, 0.5D, 0.8D, 0.5D, 0.3D);
            }
            if (!player.getAbilities().instabuild) {
                stack.shrink(1);
            }
        }
        player.getCooldowns().addCooldown(this, 20);
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        return true;
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.treasure_rainbow.rainbow_gem").withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.translatable("tooltip.treasure_rainbow.rainbow_gem.effects").withStyle(ChatFormatting.LIGHT_PURPLE));
    }
}
