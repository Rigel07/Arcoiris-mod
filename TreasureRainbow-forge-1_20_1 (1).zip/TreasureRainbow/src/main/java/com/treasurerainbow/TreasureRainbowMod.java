package com.treasurerainbow;

import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(TreasureRainbowMod.MOD_ID)
public class TreasureRainbowMod {
    public static final String MOD_ID = "treasure_rainbow";

    public TreasureRainbowMod() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();
        ModRegistry.register(modBus);
    }
}
