package com.treasurerainbow.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.treasurerainbow.TreasureRainbowMod;
import com.treasurerainbow.entity.RainbowEntity;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

/**
 * Dibuja el arco: 7 bandas de color (rojo fuera, violeta dentro), cada una un tubo cuadrado
 * translúcido que sale del cofre, sube en semicírculo y baja 2R más allá.
 */
public class RainbowRenderer extends EntityRenderer<RainbowEntity> {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(TreasureRainbowMod.MOD_ID, "textures/entity/rainbow.png");

    private static final int[][] COLORS = {
            {255, 50, 50},    // rojo
            {255, 145, 40},   // naranja
            {255, 230, 50},   // amarillo
            {70, 220, 80},    // verde
            {60, 150, 255},   // azul
            {90, 80, 225},    // añil
            {175, 80, 235},   // violeta
    };

    private static final int SEGMENTS = 40;
    private static final float BAND_WIDTH = 1.7F;
    private static final float HALF_THICKNESS = 1.1F;
    /** El arco empieza un poco bajo tierra para que los pies del arcoíris queden enterrados. */
    private static final float SINK = 2.5F;

    public RainbowRenderer(EntityRendererProvider.Context context) {
        super(context);
    }

    @Override
    public ResourceLocation getTextureLocation(RainbowEntity entity) {
        return TEXTURE;
    }

    @Override
    public void render(RainbowEntity entity, float entityYaw, float partialTick, PoseStack poseStack,
                       MultiBufferSource buffer, int packedLight) {
        float alpha = entity.getAlpha(partialTick);
        if (alpha <= 0.01F) {
            return;
        }
        float yaw = entity.getYRot() * Mth.DEG_TO_RAD;
        float dx = -Mth.sin(yaw);
        float dz = Mth.cos(yaw);
        float nx = -dz;
        float nz = dx;
        float radius = entity.getRadius();
        float shimmer = 0.92F + 0.08F * Mth.sin((entity.tickCount + partialTick) * 0.05F);
        float a = alpha * shimmer;

        VertexConsumer consumer = buffer.getBuffer(RenderType.entityTranslucent(TEXTURE));
        PoseStack.Pose pose = poseStack.last();
        Matrix4f matrix = pose.pose();
        Matrix3f normal = pose.normal();

        for (int band = 0; band < COLORS.length; band++) {
            float mid = radius + (3 - band) * BAND_WIDTH;
            float rOut = mid + BAND_WIDTH * 0.5F;
            float rIn = mid - BAND_WIDTH * 0.5F;
            int r = COLORS[band][0];
            int g = COLORS[band][1];
            int b = COLORS[band][2];
            int sideAlpha = (int) (95.0F * a);
            int faceAlpha = (int) (135.0F * a);

            for (int k = 0; k < SEGMENTS; k++) {
                float t0 = (float) Math.PI * k / SEGMENTS;
                float t1 = (float) Math.PI * (k + 1) / SEGMENTS;

                // lados (el plano del arco, visto desde los dos costados)
                for (int side = -1; side <= 1; side += 2) {
                    float lat = HALF_THICKNESS * side;
                    quad(consumer, matrix, normal, r, g, b, sideAlpha,
                            point(radius, rOut, t0, lat, dx, dz, nx, nz),
                            point(radius, rIn, t0, lat, dx, dz, nx, nz),
                            point(radius, rIn, t1, lat, dx, dz, nx, nz),
                            point(radius, rOut, t1, lat, dx, dz, nx, nz));
                }
                // cara exterior e interior (el grosor del tubo)
                for (int face = 0; face < 2; face++) {
                    float rr = face == 0 ? rOut : rIn;
                    quad(consumer, matrix, normal, r, g, b, faceAlpha,
                            point(radius, rr, t0, -HALF_THICKNESS, dx, dz, nx, nz),
                            point(radius, rr, t0, HALF_THICKNESS, dx, dz, nx, nz),
                            point(radius, rr, t1, HALF_THICKNESS, dx, dz, nx, nz),
                            point(radius, rr, t1, -HALF_THICKNESS, dx, dz, nx, nz));
                }
            }
        }
    }

    /** Punto del arco a radio {@code r}, ángulo {@code t} (0..PI) y desplazamiento lateral {@code lat}. */
    private static float[] point(float center, float r, float t, float lat, float dx, float dz, float nx, float nz) {
        float along = center - r * Mth.cos(t);
        float up = r * Mth.sin(t) - SINK;
        return new float[]{dx * along + nx * lat, up, dz * along + nz * lat};
    }

    private static void quad(VertexConsumer consumer, Matrix4f matrix, Matrix3f normal,
                             int r, int g, int b, int a, float[] p1, float[] p2, float[] p3, float[] p4) {
        vertex(consumer, matrix, normal, p1, r, g, b, a);
        vertex(consumer, matrix, normal, p2, r, g, b, a);
        vertex(consumer, matrix, normal, p3, r, g, b, a);
        vertex(consumer, matrix, normal, p4, r, g, b, a);
    }

    private static void vertex(VertexConsumer consumer, Matrix4f matrix, Matrix3f normal, float[] p,
                               int r, int g, int b, int a) {
        consumer.vertex(matrix, p[0], p[1], p[2])
                .color(r, g, b, a)
                .uv(0.5F, 0.5F)
                .overlayCoords(OverlayTexture.NO_OVERLAY)
                .uv2(LightTexture.FULL_BRIGHT)
                .normal(normal, 0.0F, 1.0F, 0.0F)
                .endVertex();
    }
}
