package com.treasurerainbow.entity;

import com.treasurerainbow.block.RainbowChestBlock;
import com.treasurerainbow.block.RainbowChestBlockEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;

/**
 * El arcoíris. Es una entidad invisible plantada donde está el cofre (el "pie" del arcoíris);
 * el arco de colores lo dibuja el cliente (ver RainbowRenderer).
 * Desaparece al caer la noche, con tormenta, con el tiempo, o poco después de que alguien abra el cofre.
 */
public class RainbowEntity extends Entity {
    public static final int FADE_IN_TICKS = 100;
    public static final int FADE_OUT_TICKS = 100;
    /** Duración máxima: unos 12 minutos. */
    private static final int DEFAULT_LIFE = 14400;

    private static final EntityDataAccessor<Boolean> DATA_FADING =
            SynchedEntityData.defineId(RainbowEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Integer> DATA_RADIUS =
            SynchedEntityData.defineId(RainbowEntity.class, EntityDataSerializers.INT);

    private int life = DEFAULT_LIFE;
    private int fadeTick;
    private boolean ignoreDay;

    public RainbowEntity(EntityType<? extends RainbowEntity> type, Level level) {
        super(type, level);
        this.noPhysics = true;
        setNoGravity(true);
    }

    @Override
    protected void defineSynchedData() {
        this.entityData.define(DATA_FADING, false);
        this.entityData.define(DATA_RADIUS, 32);
    }

    public boolean isFading() {
        return this.entityData.get(DATA_FADING);
    }

    public int getRadius() {
        return this.entityData.get(DATA_RADIUS);
    }

    public void setRadius(int radius) {
        this.entityData.set(DATA_RADIUS, Mth.clamp(radius, 12, 64));
    }

    /** Para el comando de pruebas: el arcoíris no se va al anochecer. */
    public void setIgnoreDay(boolean ignoreDay) {
        this.ignoreDay = ignoreDay;
    }

    public void startFading() {
        if (!isFading()) {
            this.entityData.set(DATA_FADING, true);
            this.fadeTick = 0;
        }
    }

    /** 0..1: aparece poco a poco y se desvanece al final (solo se usa en el cliente). */
    public float getAlpha(float partialTick) {
        float in = Mth.clamp((this.tickCount + partialTick) / FADE_IN_TICKS, 0.0F, 1.0F);
        float out = isFading() ? 1.0F - Mth.clamp((this.fadeTick + partialTick) / FADE_OUT_TICKS, 0.0F, 1.0F) : 1.0F;
        return in * out;
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) {
            if (isFading() && fadeTick < FADE_OUT_TICKS) {
                fadeTick++;
            }
            return;
        }
        if (!isFading()) {
            life--;
            boolean broken = tickCount % 10 == 0 && !isChestIntact();
            if (life <= 0 || broken || (!ignoreDay && !level().isDay())) {
                startFading();
            }
        } else {
            fadeTick++;
            if (fadeTick >= FADE_OUT_TICKS) {
                finish();
            }
        }
    }

    /** El cofre sigue ahí y nadie lo ha abierto. */
    private boolean isChestIntact() {
        BlockState state = level().getBlockState(blockPosition());
        return state.getBlock() instanceof RainbowChestBlock && state.getValue(RainbowChestBlock.SPARKLING);
    }

    /** Al terminar, un cofre que nadie reclamó se esfuma con el arcoíris. */
    private void finish() {
        if (level() instanceof ServerLevel serverLevel) {
            BlockPos pos = blockPosition();
            BlockState state = serverLevel.getBlockState(pos);
            if (state.getBlock() instanceof RainbowChestBlock && state.getValue(RainbowChestBlock.SPARKLING)) {
                BlockEntity entity = serverLevel.getBlockEntity(pos);
                if (entity instanceof RainbowChestBlockEntity chest && chest.hasUnclaimedLoot()) {
                    chest.discardLoot();
                    serverLevel.sendParticles(ParticleTypes.POOF, pos.getX() + 0.5D, pos.getY() + 0.7D, pos.getZ() + 0.5D,
                            20, 0.3D, 0.3D, 0.3D, 0.05D);
                    serverLevel.removeBlock(pos, false);
                }
            }
        }
        discard();
    }

    // ------------------------------------------------------- Comportamiento

    @Override
    public boolean isPickable() {
        return false;
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        return false;
    }

    /** Se ve desde muy lejos y no se descarta por estar su "centro" fuera de la pantalla. */
    @Override
    public boolean shouldRender(double x, double y, double z) {
        return true;
    }

    @Override
    public AABB getBoundingBoxForCulling() {
        return getBoundingBox().inflate(getRadius() * 2.0D + 6.0D);
    }

    // --------------------------------------------------------------- Guardado

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
        if (tag.contains("Life")) {
            life = tag.getInt("Life");
        }
        fadeTick = tag.getInt("FadeTick");
        ignoreDay = tag.getBoolean("IgnoreDay");
        if (tag.contains("Radius")) {
            setRadius(tag.getInt("Radius"));
        }
        if (tag.getBoolean("Fading")) {
            this.entityData.set(DATA_FADING, true);
        }
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
        tag.putInt("Life", life);
        tag.putInt("FadeTick", fadeTick);
        tag.putBoolean("IgnoreDay", ignoreDay);
        tag.putInt("Radius", getRadius());
        tag.putBoolean("Fading", isFading());
    }
}
