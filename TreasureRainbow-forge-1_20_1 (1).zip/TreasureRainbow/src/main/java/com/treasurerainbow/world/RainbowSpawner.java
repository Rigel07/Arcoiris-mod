package com.treasurerainbow.world;

import com.treasurerainbow.ModRegistry;
import com.treasurerainbow.block.RainbowChestBlock;
import com.treasurerainbow.block.RainbowChestBlockEntity;
import com.treasurerainbow.entity.RainbowEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/** Crea arcoíris (con su cofre) en sitios despejados alrededor de un jugador. */
public final class RainbowSpawner {
    private RainbowSpawner() {}

    /** Distancia mínima entre dos arcoíris. */
    private static final double MIN_SPACING = 110.0D;

    /**
     * @return la posición del cofre si se ha creado un arcoíris, o null si no se ha encontrado un buen sitio.
     */
    public static BlockPos trySpawnNear(ServerLevel level, ServerPlayer player, boolean force) {
        RandomSource random = level.random;
        BlockPos origin = player.blockPosition();

        for (int attempt = 0; attempt < 12; attempt++) {
            double angle = random.nextDouble() * Math.PI * 2.0D;
            double distance = force ? 24.0D + random.nextInt(14) : 50.0D + random.nextInt(40);
            int x = origin.getX() + (int) Math.round(Math.cos(angle) * distance);
            int z = origin.getZ() + (int) Math.round(Math.sin(angle) * distance);
            if (!level.hasChunk(x >> 4, z >> 4)) {
                continue;
            }
            int y = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);
            BlockPos pos = new BlockPos(x, y, z);
            BlockPos below = pos.below();
            BlockState ground = level.getBlockState(below);

            boolean solidGround = ground.isFaceSturdy(level, below, Direction.UP) && ground.getFluidState().isEmpty();
            if (!solidGround || !level.getFluidState(pos).isEmpty() || !level.getBlockState(pos).canBeReplaced()
                    || !level.canSeeSky(pos)) {
                continue;
            }
            if (!force && !level.getEntitiesOfClass(RainbowEntity.class, new AABB(pos).inflate(MIN_SPACING)).isEmpty()) {
                continue;
            }
            if (spawnRainbow(level, pos, force)) {
                return pos;
            }
        }
        return null;
    }

    /** Planta el cofre en {@code pos} y levanta el arcoíris que acaba en él. */
    public static boolean spawnRainbow(ServerLevel level, BlockPos pos, boolean ignoreDay) {
        RandomSource random = level.random;
        float yaw = random.nextFloat() * 360.0F;
        float rad = yaw * Mth.DEG_TO_RAD;
        Direction facing = Direction.getNearest(-Mth.sin(rad), 0.0D, Mth.cos(rad));

        BlockState chest = ModRegistry.RAINBOW_CHEST.get().defaultBlockState()
                .setValue(RainbowChestBlock.FACING, facing)
                .setValue(RainbowChestBlock.SPARKLING, true);
        level.setBlock(pos, chest, 3);
        BlockEntity entity = level.getBlockEntity(pos);
        if (entity instanceof RainbowChestBlockEntity chestEntity) {
            chestEntity.setLootTable(ModRegistry.TREASURE_LOOT, random.nextLong());
        }

        RainbowEntity rainbow = ModRegistry.RAINBOW.get().create(level);
        if (rainbow == null) {
            level.removeBlock(pos, false);
            return false;
        }
        rainbow.moveTo(pos.getX() + 0.5D, pos.getY(), pos.getZ() + 0.5D, yaw, 0.0F);
        rainbow.setRadius(26 + random.nextInt(14));
        rainbow.setIgnoreDay(ignoreDay);
        level.addFreshEntity(rainbow);

        level.sendParticles(ParticleTypes.END_ROD, pos.getX() + 0.5D, pos.getY() + 1.0D, pos.getZ() + 0.5D,
                30, 0.5D, 0.8D, 0.5D, 0.05D);
        return true;
    }

    /** Alguien ha abierto el cofre por primera vez: celebración y el cofre deja de brillar. */
    public static void onTreasureClaimed(ServerLevel level, BlockPos pos) {
        BlockState state = level.getBlockState(pos);
        if (state.getBlock() instanceof RainbowChestBlock && state.getValue(RainbowChestBlock.SPARKLING)) {
            level.setBlock(pos, state.setValue(RainbowChestBlock.SPARKLING, false), 3);
        }
        Vec3 c = Vec3.atCenterOf(pos).add(0.0D, 0.8D, 0.0D);
        level.sendParticles(ParticleTypes.TOTEM_OF_UNDYING, c.x, c.y, c.z, 60, 0.4D, 0.5D, 0.4D, 0.4D);
        level.sendParticles(ParticleTypes.FIREWORK, c.x, c.y, c.z, 30, 0.3D, 0.4D, 0.3D, 0.2D);
        level.playSound(null, pos, SoundEvents.UI_TOAST_CHALLENGE_COMPLETE, SoundSource.BLOCKS, 1.0F, 1.0F);
        level.playSound(null, pos, SoundEvents.FIREWORK_ROCKET_TWINKLE, SoundSource.BLOCKS, 1.2F, 1.0F);
    }

    public static void announce(ServerPlayer player) {
        player.displayClientMessage(Component.translatable("message.treasure_rainbow.appeared"), true);
    }
}
