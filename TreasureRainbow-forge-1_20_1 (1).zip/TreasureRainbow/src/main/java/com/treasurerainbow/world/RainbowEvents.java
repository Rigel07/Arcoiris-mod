package com.treasurerainbow.world;

import com.treasurerainbow.TreasureRainbowMod;
import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.Level;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = TreasureRainbowMod.MOD_ID)
public class RainbowEvents {
    /** Cada cuántos ticks se "tira el dado" para crear un arcoíris (400 = 20 segundos). */
    private static final int CHECK_INTERVAL = 400;
    /** Probabilidad por jugador y comprobación en un día soleado. */
    private static final double BASE_CHANCE = 0.06D;
    /** Probabilidad justo después de que pare de llover. */
    private static final double AFTER_RAIN_CHANCE = 0.40D;
    /** Cuánto dura ese "después de la lluvia" (ticks). */
    private static final int AFTER_RAIN_TICKS = 6000;

    private static boolean wasRaining;
    private static int afterRain;

    @SubscribeEvent
    public static void onLevelTick(TickEvent.LevelTickEvent event) {
        if (event.phase != TickEvent.Phase.END || !(event.level instanceof ServerLevel level)
                || level.dimension() != Level.OVERWORLD) {
            return;
        }
        boolean raining = level.isRaining();
        if (wasRaining && !raining) {
            afterRain = AFTER_RAIN_TICKS;
        }
        wasRaining = raining;
        if (afterRain > 0) {
            afterRain--;
        }

        if (level.getGameTime() % CHECK_INTERVAL != 0 || raining || !level.isDay()) {
            return;
        }
        double chance = afterRain > 0 ? AFTER_RAIN_CHANCE : BASE_CHANCE;
        for (ServerPlayer player : level.players()) {
            if (player.isSpectator() || level.random.nextDouble() > chance) {
                continue;
            }
            if (RainbowSpawner.trySpawnNear(level, player, false) != null) {
                RainbowSpawner.announce(player);
            }
        }
    }

    /** /rainbow (solo operadores): crea un arcoíris cerca de ti para probar. */
    @SubscribeEvent
    public static void onRegisterCommands(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("rainbow")
                .requires(source -> source.hasPermission(2))
                .executes(context -> {
                    ServerPlayer player = context.getSource().getPlayerOrException();
                    BlockPos pos = RainbowSpawner.trySpawnNear(context.getSource().getLevel(), player, true);
                    player.displayClientMessage(Component.translatable(pos != null
                            ? "message.treasure_rainbow.command_ok" : "message.treasure_rainbow.command_fail"), false);
                    return pos != null ? 1 : 0;
                }));
    }
}
