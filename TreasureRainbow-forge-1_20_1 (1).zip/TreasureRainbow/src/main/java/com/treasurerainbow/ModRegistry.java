package com.treasurerainbow;

import com.treasurerainbow.block.RainbowChestBlock;
import com.treasurerainbow.block.RainbowChestBlockEntity;
import com.treasurerainbow.entity.RainbowEntity;
import com.treasurerainbow.item.RainbowGemItem;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModRegistry {
    private ModRegistry() {}

    private static final String ID = TreasureRainbowMod.MOD_ID;

    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, ID);
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, ID);
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES = DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES, ID);
    public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, ID);
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, ID);

    /** Botín del cofre del arcoíris (data/treasure_rainbow/loot_tables/chests/rainbow_treasure.json). */
    public static final ResourceLocation TREASURE_LOOT = new ResourceLocation(ID, "chests/rainbow_treasure");

    // ---- Bloques ----
    public static final RegistryObject<Block> RAINBOW_CHEST = BLOCKS.register("rainbow_chest",
            () -> new RainbowChestBlock(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.GOLD)
                    .strength(2.5F)
                    .sound(SoundType.WOOD)
                    .noOcclusion()
                    .lightLevel(state -> state.getValue(RainbowChestBlock.SPARKLING) ? 7 : 0)));

    public static final RegistryObject<Block> RAINBOW_WOOL = BLOCKS.register("rainbow_wool",
            () -> new Block(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.COLOR_PINK)
                    .strength(0.8F)
                    .sound(SoundType.WOOL)));

    public static final RegistryObject<BlockEntityType<RainbowChestBlockEntity>> RAINBOW_CHEST_BE = BLOCK_ENTITIES.register(
            "rainbow_chest",
            () -> BlockEntityType.Builder.of(RainbowChestBlockEntity::new, RAINBOW_CHEST.get()).build(null));

    // ---- Entidad (el arcoíris) ----
    public static final RegistryObject<EntityType<RainbowEntity>> RAINBOW = ENTITIES.register("rainbow",
            () -> EntityType.Builder.<RainbowEntity>of(RainbowEntity::new, MobCategory.MISC)
                    .sized(0.5F, 0.5F)
                    .clientTrackingRange(16)
                    .updateInterval(20)
                    .fireImmune()
                    .build(ID + ":rainbow"));

    // ---- Objetos ----
    public static final RegistryObject<Item> RAINBOW_GEM = ITEMS.register("rainbow_gem",
            () -> new RainbowGemItem(new Item.Properties().rarity(Rarity.EPIC).stacksTo(16)));
    public static final RegistryObject<Item> RAINBOW_DUST = ITEMS.register("rainbow_dust",
            () -> new Item(new Item.Properties().rarity(Rarity.UNCOMMON)));
    public static final RegistryObject<Item> RAINBOW_CHEST_ITEM = ITEMS.register("rainbow_chest",
            () -> new BlockItem(RAINBOW_CHEST.get(), new Item.Properties().rarity(Rarity.RARE)));
    public static final RegistryObject<Item> RAINBOW_WOOL_ITEM = ITEMS.register("rainbow_wool",
            () -> new BlockItem(RAINBOW_WOOL.get(), new Item.Properties()));

    // ---- Pestaña creativa ----
    public static final RegistryObject<CreativeModeTab> TAB = TABS.register("treasure_rainbow_tab",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.treasure_rainbow"))
                    .icon(() -> new ItemStack(RAINBOW_GEM.get()))
                    .displayItems((params, output) -> {
                        output.accept(RAINBOW_GEM.get());
                        output.accept(RAINBOW_DUST.get());
                        output.accept(RAINBOW_CHEST_ITEM.get());
                        output.accept(RAINBOW_WOOL_ITEM.get());
                    })
                    .build());

    public static void register(IEventBus bus) {
        BLOCKS.register(bus);
        ITEMS.register(bus);
        BLOCK_ENTITIES.register(bus);
        ENTITIES.register(bus);
        TABS.register(bus);
    }
}
